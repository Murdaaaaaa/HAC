/**
 * @type {import('next').NextConfig}
 *
 * The configuration intentionally keeps strict mode enabled and
 * does not add any flashy features. Keeping the UI restrained
 * and accessible ensures it works across devices, including
 * iPhone 13, without unnecessary modern flair.
 */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    appDir: true
  }
};

module.exports = nextConfig;