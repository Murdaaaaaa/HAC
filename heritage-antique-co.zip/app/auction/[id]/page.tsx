"use client";

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Image from 'next/image';
import Countdown from '../../../components/Countdown';
import Divider from '../../../components/Divider';
import { getUserFromStorage, hasRequiredTier, User } from '../../../lib/auth';

interface LotDetail {
  id: number;
  title: string;
  imageSrc: string;
  description: string;
  endTime: Date;
  requiredTier: 'Registered Collector' | 'Auction Collector' | 'Heritage Patron';
}

// Detail map for our sample lots
const LOT_DETAILS: Record<number, LotDetail> = {
  1: {
    id: 1,
    title: 'Antique Glass Goblet',
    imageSrc: '/items/goblet.png',
    description:
      'This exquisite 19th‑century glass goblet features delicate etching and a baluster stem. It was hand‑blown by a master artisan and remains in excellent condition. It is a testament to the elegance of Victorian tableware.',
    endTime: new Date('2026-05-01T17:00:00Z'),
    requiredTier: 'Registered Collector',
  },
  2: {
    id: 2,
    title: 'Victorian Glass Pitcher',
    imageSrc: '/items/pitcher.png',
    description:
      'A rare pitcher from the Victorian era, distinguished by its graceful curves and subtle embossing. The pitcher has served countless gatherings and now awaits a new steward.',
    endTime: new Date('2026-05-05T17:00:00Z'),
    requiredTier: 'Auction Collector',
  },
  3: {
    id: 3,
    title: 'Art Deco Decanter',
    imageSrc: '/items/decanter.png',
    description:
      'An Art Deco decanter crafted during the roaring 1920s. Its geometric patterning and heavy base speak to the bold aesthetics of the period. This piece would grace any connoisseur’s collection.',
    endTime: new Date('2026-05-10T17:00:00Z'),
    requiredTier: 'Heritage Patron',
  },
};

/**
 * Single auction lot page. Focuses attention on one item with large
 * imagery and narrative description. A countdown displays time
 * remaining if the visitor is authorised. Otherwise a polite message
 * explains that the material is reserved.
 */
export default function AuctionDetailPage() {
  const router = useRouter();
  const params = useParams<{ id: string }>();
  const lotId = Number(params.id);
  const [user, setUser] = useState<User | null>(null);
  const lot = LOT_DETAILS[lotId];

  useEffect(() => {
    const stored = getUserFromStorage();
    if (!stored) {
      router.replace('/login');
      return;
    }
    setUser(stored);
  }, [router]);

  if (!lot) {
    return (
      <section className="mt-12 font-serif">
        <p>Lot not found.</p>
      </section>
    );
  }
  if (!user) return null;

  const authorised = hasRequiredTier(user, lot.requiredTier as any);

  return (
    <section className="mt-12">
      <h2 className="font-display text-3xl mb-4">{lot.title}</h2>
      {authorised ? (
        <>
          <div className="mb-6">
            <Image
              src={lot.imageSrc}
              alt={lot.title}
              width={1000}
              height={750}
              className="w-full h-auto object-cover"
            />
          </div>
          <div className="font-serif leading-relaxed mb-4">
            {lot.description}
          </div>
          <Countdown endTime={lot.endTime} />
          <Divider />
          <button
            className="uppercase tracking-wider px-6 py-3 border border-brass text-charcoal hover:bg-brass hover:text-parchment transition-colors font-serif"
            onClick={() => alert('Bidding functionality is not implemented in this demo.')}
          >
            Place Bid
          </button>
        </>
      ) : (
        <p className="font-serif italic">This material is reserved for {lot.requiredTier}s.</p>
      )}
    </section>
  );
}