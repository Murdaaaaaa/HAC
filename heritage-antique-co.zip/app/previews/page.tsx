"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import AuctionLot from '../../components/AuctionLot';
import Divider from '../../components/Divider';
import { getUserFromStorage, hasRequiredTier, User } from '../../lib/auth';

interface PreviewLot {
  id: number;
  title: string;
  imageSrc: string;
  excerpt: string;
  requiredTier: 'Heritage Patron';
}

const PREVIEW_LOTS: PreviewLot[] = [
  {
    id: 3,
    title: 'Art Deco Decanter',
    imageSrc: '/items/decanter.png',
    excerpt: 'A rare Art Deco decanter with geometric motifs, available for early viewing by our patrons.',
    requiredTier: 'Heritage Patron',
  },
];

/**
 * Previews page lists lots available for early viewing. Only
 * visitors with the highest tier (Heritage Patron) may access this
 * page. Lower tiers are politely refused entry.
 */
export default function PreviewsPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    const stored = getUserFromStorage();
    if (!stored) {
      router.replace('/login');
      return;
    }
    setUser(stored);
  }, [router]);
  if (!user) return null;
  const authorised = hasRequiredTier(user, 'Heritage Patron');
  if (!authorised) {
    return (
      <section className="mt-12 font-serif italic text-center">
        This material is reserved for Heritage Patrons.
      </section>
    );
  }
  return (
    <section className="mt-12">
      <h2 className="font-display text-3xl mb-6">Early Previews</h2>
      {PREVIEW_LOTS.map((lot) => (
        <div key={lot.id} className="mb-12">
          <AuctionLot
            id={lot.id}
            title={lot.title}
            imageSrc={lot.imageSrc}
            excerpt={lot.excerpt}
            preview
            tierLabel="Heritage Patron"
          />
          <Divider />
        </div>
      ))}
    </section>
  );
}