"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { saveUserToStorage, Tier } from '../../lib/auth';

/**
 * Login page. A simple form invites the visitor to enter their name
 * and choose a collector tier. Upon submission a mock user record
 * is stored in localStorage and the visitor is redirected to the
 * dashboard. No decorative illustrations or cards are used.
 */
export default function LoginPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [tier, setTier] = useState<Tier>('Registered Collector');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Generate a simple ID based on timestamp for demonstration
    const id = Date.now().toString();
    saveUserToStorage({ id, name: name.trim() || 'Collector', tier });
    router.push('/dashboard');
  };

  return (
    <section className="mt-20 max-w-md mx-auto">
      <h2 className="font-display text-3xl text-center mb-4">Collector Login</h2>
      <p className="font-serif text-center mb-6">
        Enter your name and select your collector tier to continue.
      </p>
      <form onSubmit={handleSubmit} className="space-y-4 font-serif">
        <div className="flex flex-col">
          <label htmlFor="name" className="uppercase text-xs tracking-widest mb-1">
            Name
          </label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border border-charcoal bg-transparent px-3 py-2 focus:outline-none focus:border-antique-gold text-charcoal placeholder-charcoal/50"
            placeholder="e.g. Jane Doe"
            required
          />
        </div>
        <div className="flex flex-col">
          <label htmlFor="tier" className="uppercase text-xs tracking-widest mb-1">
            Tier
          </label>
          <select
            id="tier"
            value={tier}
            onChange={(e) => setTier(e.target.value as Tier)}
            className="border border-charcoal bg-transparent px-3 py-2 focus:outline-none focus:border-antique-gold text-charcoal"
          >
            <option value="Registered Collector">Registered Collector</option>
            <option value="Auction Collector">Auction Collector</option>
            <option value="Heritage Patron">Heritage Patron</option>
          </select>
        </div>
        <div className="text-center">
          <button
            type="submit"
            className="uppercase tracking-wider px-6 py-2 border border-brass text-charcoal hover:bg-brass hover:text-parchment transition-colors"
          >
            Enter
          </button>
        </div>
      </form>
    </section>
  );
}