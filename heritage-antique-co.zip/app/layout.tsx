import './globals.css';
import '../styles/theme.css';

import Header from '../components/Header';
import Footer from '../components/Footer';

import { Playfair_Display, Cormorant_Garamond, Great_Vibes } from 'next/font/google';

// Define the fonts with CSS variable names. The `display` strategy
// ensures they load gracefully while maintaining the correct tone.
const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
});

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-cormorant',
  display: 'swap',
});

const script = Great_Vibes({
  subsets: ['latin'],
  weight: '400',
  variable: '--font-script',
  display: 'swap',
});

export const metadata = {
  title: 'Heritage Antique Co.',
  description: 'Private collector portal and auction system for Heritage Antique Co.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${playfair.variable} ${cormorant.variable} ${script.variable}`}>
      <body className="fade-in">
        <div className="max-w-4xl mx-auto px-4">
          <Header />
          <main>{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  );
}