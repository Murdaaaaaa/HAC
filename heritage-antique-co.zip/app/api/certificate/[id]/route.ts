import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * API route to generate a PDF provenance certificate. This handler
 * demonstrates how a server‑side PDF might be assembled using
 * PDFKit. It is not production‑ready but provides a working
 * example for preview purposes. In a real deployment data would be
 * fetched from the database based on the certificate ID.
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const { id } = params;
  // Lazy import PDFKit to reduce startup cost
  const PDFDocument = (await import('pdfkit')).default;
  const doc = new PDFDocument({ size: 'A4', margin: 72 });
  const chunks: Uint8Array[] = [];
  // Collect PDF data into chunks
  doc.on('data', (chunk) => chunks.push(chunk));
  // Document content
  doc
    .fontSize(26)
    .font('Times-Bold')
    .text('Heritage Antique Co.', { align: 'center' })
    .moveDown(0.5)
    .fontSize(14)
    .font('Times-Italic')
    .text('Heritage At Home', { align: 'center' })
    .moveDown(1.5);
  doc
    .fontSize(20)
    .font('Times-Roman')
    .text('Certificate of Provenance', { align: 'center', underline: true })
    .moveDown(1.5);
  // Dummy certificate data
  const certificateData = {
    itemTitle: id === '1' ? 'Victorian Glass Vase' : 'Art Deco Decanter',
    acquisitionDate: id === '1' ? 'March 12, 2025' : 'August 27, 2025',
    collectorName: 'Collector',
    statement:
      'This document certifies that the bearer of this certificate is the steward of the item described herein. Heritage Antique Co. attests to the authenticity and provenance of the piece.',
  };
  doc
    .fontSize(16)
    .font('Times-Bold')
    .text(certificateData.itemTitle, { align: 'left' })
    .moveDown(0.5);
  doc
    .fontSize(12)
    .font('Times-Roman')
    .text(`Acquisition Date: ${certificateData.acquisitionDate}`)
    .moveDown(0.5)
    .text(`Collector: ${certificateData.collectorName}`)
    .moveDown(1);
  doc
    .fontSize(12)
    .font('Times-Roman')
    .text(certificateData.statement, {
      align: 'justify',
    })
    .moveDown(2);
  doc
    .fontSize(12)
    .font('Times-Italic')
    .text('— Heritage Antique Co.', { align: 'right' });
  doc.end();
  const buffer = Buffer.concat(chunks);
  return new NextResponse(buffer, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename=certificate-${id}.pdf`,
    },
  });
}