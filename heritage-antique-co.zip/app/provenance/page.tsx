"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getUserFromStorage, User } from '../../lib/auth';

interface Certificate {
  id: number;
  itemTitle: string;
  acquisitionDate: string;
  statement: string;
}

/**
 * Provenance page displays the list of owned items and allows the
 * collector to download PDF certificates. The layout echoes the
 * dashboard but focuses solely on the certificates. This page is
 * accessible to any logged‑in user; non‑logged‑in visitors are
 * redirected to the login page.
 */
export default function ProvenancePage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [certificates, setCertificates] = useState<Certificate[]>([]);

  useEffect(() => {
    const stored = getUserFromStorage();
    if (!stored) {
      router.replace('/login');
      return;
    }
    setUser(stored);
    // Duplicate the sample certificates from the dashboard
    setCertificates([
      {
        id: 1,
        itemTitle: 'Victorian Glass Vase',
        acquisitionDate: '2025-03-12',
        statement: 'Certificate of stewardship for the Victorian Glass Vase.',
      },
      {
        id: 2,
        itemTitle: 'Art Deco Decanter',
        acquisitionDate: '2025-08-27',
        statement: 'Certificate of stewardship for the Art Deco Decanter.',
      },
    ]);
  }, [router]);

  if (!user) return null;

  return (
    <section className="mt-12">
      <h2 className="font-display text-3xl mb-4">Provenance Certificates</h2>
      <p className="font-serif mb-6 italic">
        Download certificates for your owned items. Each PDF affirms
        your role as steward of these antiques.
      </p>
      {certificates.length === 0 ? (
        <p className="font-serif">You do not currently own any certified items.</p>
      ) : (
        <ul className="space-y-6">
          {certificates.map((cert) => (
            <li key={cert.id}>
              <div className="font-display text-xl mb-1">{cert.itemTitle}</div>
              <div className="font-serif text-sm mb-1">
                Acquisition date: {new Date(cert.acquisitionDate).toLocaleDateString()}
              </div>
              <div className="font-serif text-sm mb-2">{cert.statement}</div>
              <a
                href={`/api/certificate/${cert.id}`}
                className="text-antique-gold font-serif underline"
              >
                Download Certificate
              </a>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}