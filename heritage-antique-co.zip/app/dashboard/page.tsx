"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import BadgeSeal from '../../components/BadgeSeal';
import Divider from '../../components/Divider';
import { getUserFromStorage, logout, User } from '../../lib/auth';

interface Certificate {
  id: number;
  itemTitle: string;
  acquisitionDate: string;
  statement: string;
}

/**
 * Dashboard (Collector Hub)
 *
 * Displays the current collector’s name, tier, badge seals and a
 * quiet welcome. A list of provenance certificates is shown with a
 * link to download each as a PDF. There are no charts or gamified
 * widgets. When no user is present in storage the visitor is
 * redirected to the login page.
 */
export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [certificates, setCertificates] = useState<Certificate[]>([]);

  useEffect(() => {
    const stored = getUserFromStorage();
    if (!stored) {
      router.replace('/login');
      return;
    }
    setUser(stored);
    // Populate sample certificates for demonstration
    setCertificates([
      {
        id: 1,
        itemTitle: 'Victorian Glass Vase',
        acquisitionDate: '2025-03-12',
        statement: 'Certificate of stewardship for the Victorian Glass Vase.',
      },
      {
        id: 2,
        itemTitle: 'Art Deco Decanter',
        acquisitionDate: '2025-08-27',
        statement: 'Certificate of stewardship for the Art Deco Decanter.',
      },
    ]);
  }, [router]);

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  if (!user) return null;

  return (
    <section className="mt-12">
      <h2 className="font-display text-3xl mb-2">Welcome, {user.name}</h2>
      <p className="font-serif mb-4">Tier:&nbsp;<BadgeSeal tier={user.tier} /></p>
      <Divider />
      <p className="font-serif mb-6 italic">
        The registry of your acquisitions is presented below. Each
        certificate affirms your stewardship of a piece of history.
      </p>
      <div>
        {certificates.length === 0 ? (
          <p className="font-serif">You do not currently own any certified items.</p>
        ) : (
          <ul className="space-y-6">
            {certificates.map((cert) => (
              <li key={cert.id}>
                <div className="font-display text-xl mb-1">{cert.itemTitle}</div>
                <div className="font-serif text-sm mb-1">
                  Acquisition date: {new Date(cert.acquisitionDate).toLocaleDateString()}
                </div>
                <div className="font-serif text-sm mb-2">{cert.statement}</div>
                <a
                  href={`/api/certificate/${cert.id}`}
                  className="text-antique-gold font-serif underline"
                >
                  Download Certificate
                </a>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div className="mt-10">
        <button
          onClick={handleLogout}
          className="uppercase tracking-wider px-6 py-2 border border-brass text-charcoal hover:bg-brass hover:text-parchment transition-colors font-serif"
        >
          Log Out
        </button>
      </div>
    </section>
  );
}