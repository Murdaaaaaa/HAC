"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { getUserFromStorage } from '../lib/auth';

/**
 * Landing page. It detects whether a user is already logged in
 * (via localStorage) and redirects them to the dashboard. Otherwise
 * it invites them to log in. This page intentionally keeps content
 * sparse to respect the heritage mood.
 */
export default function HomePage() {
  const router = useRouter();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const user = getUserFromStorage();
    if (user) {
      router.replace('/dashboard');
    } else {
      setReady(true);
    }
  }, [router]);

  if (!ready) return null;

  return (
    <section className="text-center mt-20">
      <h2 className="font-display text-3xl mb-4">Welcome to Heritage Antique Co.</h2>
      <p className="font-serif mb-6 mx-auto max-w-2xl">
        You have discovered the private collector portal. To browse our
        archives, attend auctions and access provenance documents you
        must first log in.
      </p>
      <Link
        href="/login"
        className="font-serif uppercase tracking-wider text-antique-gold hover:underline"
      >
        Proceed to Login
      </Link>
    </section>
  );
}