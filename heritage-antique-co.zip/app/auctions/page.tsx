"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import AuctionLot from '../../components/AuctionLot';
import Divider from '../../components/Divider';
import { getUserFromStorage, hasRequiredTier, User } from '../../lib/auth';

interface Lot {
  id: number;
  title: string;
  imageSrc: string;
  excerpt: string;
  endTime: Date;
  requiredTier: 'Registered Collector' | 'Auction Collector' | 'Heritage Patron';
}

// Sample lots for demonstration. In a real system these would be
// fetched from the database depending on the visitor’s tier.
const LOTS: Lot[] = [
  {
    id: 1,
    title: 'Antique Glass Goblet',
    imageSrc: '/items/goblet.png',
    excerpt: 'An ornate 19th‑century glass goblet with fine etching.',
    endTime: new Date('2026-05-01T17:00:00Z'),
    requiredTier: 'Registered Collector',
  },
  {
    id: 2,
    title: 'Victorian Glass Pitcher',
    imageSrc: '/items/pitcher.png',
    excerpt: 'A Victorian era pitcher showcasing elegant lines and craftsmanship.',
    endTime: new Date('2026-05-05T17:00:00Z'),
    requiredTier: 'Auction Collector',
  },
  {
    id: 3,
    title: 'Art Deco Decanter',
    imageSrc: '/items/decanter.png',
    excerpt: 'A rare Art Deco glass decanter with intricate geometric patterns.',
    endTime: new Date('2026-05-10T17:00:00Z'),
    requiredTier: 'Heritage Patron',
  },
];

/**
 * Auctions listing page. Displays available auction lots in a vertical
 * list. Each lot is shown using the AuctionLot component. If the
 * visitor’s tier does not meet the required tier of a lot a polite
 * refusal message is displayed instead of the lot’s details.
 */
export default function AuctionsPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    const stored = getUserFromStorage();
    if (!stored) {
      router.replace('/login');
      return;
    }
    setUser(stored);
  }, [router]);
  if (!user) return null;
  return (
    <section className="mt-12">
      <h2 className="font-display text-3xl mb-6">Auctions</h2>
      {LOTS.map((lot) => {
        const allowed = hasRequiredTier(user, lot.requiredTier as any);
        return (
          <div key={lot.id} className="mb-12">
            {allowed ? (
              <AuctionLot
                id={lot.id}
                title={lot.title}
                imageSrc={lot.imageSrc}
                excerpt={lot.excerpt}
                endTime={lot.endTime}
              />
            ) : (
              <div className="font-serif italic text-center">
                This material is reserved for {lot.requiredTier}s.
              </div>
            )}
            <Divider />
          </div>
        );
      })}
    </section>
  );
}