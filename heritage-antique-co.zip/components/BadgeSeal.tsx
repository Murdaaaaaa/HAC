import type { Tier } from '../lib/auth';

interface BadgeSealProps {
  tier: Tier;
}

/**
 * Renders a badge seal indicating the collector's tier. Badges are
 * outlined rectangles with uppercase serif text and restrained
 * colouring. No icons or emojis are used.
 */
export default function BadgeSeal({ tier }: BadgeSealProps) {
  return (
    <span className="inline-block border border-brass text-xs font-serif uppercase tracking-widest px-4 py-1 text-charcoal">
      {tier}
    </span>
  );
}