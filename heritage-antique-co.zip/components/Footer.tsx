/**
 * A modest footer that reflects the restrained identity of the brand.
 * It sits quietly at the bottom of pages with no borders or decorative
 * devices. On mobile it remains centred and legible.
 */
export default function Footer() {
  return (
    <footer className="mt-12 mb-8 text-center text-xs font-serif">
      <p className="tracking-wide">&copy; {new Date().getFullYear()} Heritage Antique Co.</p>
    </footer>
  );
}