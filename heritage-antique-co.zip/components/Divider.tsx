/**
 * Divider component draws a simple horizontal line used to
 * separate sections. It uses the brass colour for subtlety
 * and does not cast any shadow.
 */
export default function Divider() {
  return <hr className="border-t border-brass my-8" />;
}