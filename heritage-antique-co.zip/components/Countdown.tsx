import { useEffect, useState } from 'react';

interface CountdownProps {
  endTime: Date;
}

/**
 * Countdown component renders a text-only countdown to an end date.
 * It updates every minute and omits seconds for a calm presentation.
 */
export default function Countdown({ endTime }: CountdownProps) {
  const calculateRemaining = () => {
    const now = new Date();
    const diffMs = endTime.getTime() - now.getTime();
    if (diffMs <= 0) return { days: 0, hours: 0 };
    const totalHours = Math.floor(diffMs / (1000 * 60 * 60));
    const days = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    return { days, hours };
  };
  const [remaining, setRemaining] = useState(calculateRemaining());
  useEffect(() => {
    const timer = setInterval(() => {
      setRemaining(calculateRemaining());
    }, 60000);
    // update at mount to avoid showing stale value
    setRemaining(calculateRemaining());
    return () => clearInterval(timer);
  }, []);
  const { days, hours } = remaining;
  if (days <= 0 && hours <= 0) {
    return <p className="font-serif italic">Bidding has concluded.</p>;
  }
  return (
    <p className="font-serif italic">
      Bidding concludes in{' '}
      {days > 0 ? `${days} day${days === 1 ? '' : 's'}` : ''}
      {days > 0 && hours > 0 ? ', ' : ''}
      {hours > 0 ? `${hours} hour${hours === 1 ? '' : 's'}` : ''}.
    </p>
  );
}