import Link from 'next/link';
import Image from 'next/image';
import Countdown from './Countdown';

export interface AuctionLotProps {
  id: number | string;
  title: string;
  imageSrc: string;
  excerpt: string;
  endTime?: Date;
  preview?: boolean;
  tierLabel?: string;
}

/**
 * Represents a single lot entry in the auctions or previews lists. It
 * eschews card styling in favour of clean typography and imagery. When
 * an end time is provided, a countdown is shown; otherwise the lot is
 * considered part of an early preview and may include a tier label.
 */
export default function AuctionLot({ id, title, imageSrc, excerpt, endTime, preview, tierLabel }: AuctionLotProps) {
  return (
    <article className="mb-12">
      <h2 className="font-display text-2xl tracking-wide mb-2">
        <Link href={`/auction/${id}`} className="hover:text-antique-gold">
          {title}
        </Link>
      </h2>
      {/* Image */}
      <div className="w-full mb-4">
        <Image
          src={imageSrc}
          alt={title}
          width={800}
          height={600}
          className="object-cover w-full h-auto"
        />
      </div>
      {/* Excerpt / description */}
      <p className="font-serif leading-relaxed mb-2">
        {excerpt}
      </p>
      {preview && tierLabel ? (
        <p className="text-xs uppercase tracking-wide font-serif text-antique-gold">Early Preview — {tierLabel}</p>
      ) : null}
      {endTime ? <Countdown endTime={endTime} /> : null}
    </article>
  );
}