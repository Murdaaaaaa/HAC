import Link from 'next/link';
import Image from 'next/image';
import { useState } from 'react';

/**
 * Header component
 *
 * Displays the Heritage Antique Co. logo, house name and
 * navigation. The navigation collapses into a hamburger on
 * smaller screens to remain usable on an iPhone 13. Under no
 * circumstances does the header add shadows or bright backgrounds.
 */
export default function Header() {
  const [open, setOpen] = useState(false);
  const navLinks = [
    { href: '/dashboard', label: 'Archive' },
    { href: '/auctions', label: 'Auctions' },
    { href: '/previews', label: 'Previews' },
    { href: '/dashboard', label: 'Collectors' },
    { href: '/provenance', label: 'Provenance' },
  ];

  return (
    <header className="mb-8 text-center pt-8">
      <div className="flex flex-col items-center">
        {/* Logo */}
        <Image
          src="/logo.png"
          alt="Heritage Antique Co. logo"
          width={180}
          height={180}
          priority
          className="mb-2 w-auto h-24 object-contain"
        />
        <h1 className="font-display text-3xl tracking-wider uppercase mt-2">
          Heritage Antique Co.
        </h1>
        {/* Secondary label: HEIRLOOMS */}
        <div className="mt-1 text-xs tracking-widest uppercase font-serif">
          Heirlooms
        </div>
        {/* Tagline in script */}
        <div className="mt-1 text-sm font-script italic">
          Heritage At Home
        </div>
      </div>
      {/* Navigation: collapsed into hamburger on small screens */}
      <nav className="mt-6">
        <div className="md:hidden flex justify-center">
          {/* Hamburger button */}
          <button
            onClick={() => setOpen(!open)}
            aria-label="Toggle navigation menu"
            className="text-charcoal focus:outline-none p-2"
          >
            <span className="block w-6 h-0.5 bg-charcoal mb-1" />
            <span className="block w-6 h-0.5 bg-charcoal mb-1" />
            <span className="block w-6 h-0.5 bg-charcoal" />
          </button>
        </div>
        <ul
          className={`mt-2 space-y-2 md:space-y-0 md:flex md:space-x-8 justify-center text-sm uppercase tracking-wide font-serif ${
            open ? '' : 'hidden md:flex'
          }`}
        >
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link href={link.href} className="hover:text-antique-gold">
                {link.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}