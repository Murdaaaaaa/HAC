import type { Tier } from './auth';

// Define which collector tier is required to access each page. If a page
// is absent from this map, it is accessible to any logged‑in user.
export const pageTierRequirements: Record<string, Tier> = {
  '/dashboard': 'Registered Collector',
  '/auctions': 'Registered Collector',
  '/auction': 'Registered Collector',
  '/previews': 'Heritage Patron',
  '/provenance': 'Registered Collector',
};