/**
 * Data about the available collector tiers. This can be extended to include
 * copy for the dashboard or to drive badges. For now it exposes the
 * canonical names and the order in which they rank.
 */
export interface TierInfo {
  name: 'Registered Collector' | 'Auction Collector' | 'Heritage Patron';
  description: string;
  badgeLabel: string;
}

export const tiers: TierInfo[] = [
  {
    name: 'Registered Collector',
    description: 'Entry tier for catalog browsing and personal provenance documents.',
    badgeLabel: 'Registered Collector',
  },
  {
    name: 'Auction Collector',
    description: 'Able to bid on public auctions and access select previews.',
    badgeLabel: 'Auction Collector',
  },
  {
    name: 'Heritage Patron',
    description: 'Full access to early previews, private auctions and stewardship perks.',
    badgeLabel: 'Heritage Patron',
  },
];