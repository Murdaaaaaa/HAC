/*
 * Lightweight authentication helpers for the demonstration build.
 *
 * The collector portal is intended to run privately for preview
 * purposes. Instead of integrating a full authentication provider
 * like Clerk or NextAuth, this module stores a mock user object
 * in localStorage. In a production deployment you would replace
 * these functions with secure server‑side authentication and
 * tier enforcement.
 */

export type Tier = 'Registered Collector' | 'Auction Collector' | 'Heritage Patron';

export interface User {
  id: string;
  name: string;
  tier: Tier;
}

const STORAGE_KEY = 'heritage_user';

/**
 * Retrieve the current user from localStorage if it exists. This
 * function should only be called in browser contexts.
 */
export function getUserFromStorage(): User | null {
  if (typeof window === 'undefined') return null;
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as User;
  } catch {
    return null;
  }
}

/**
 * Persist a user record to localStorage. When the user logs in
 * successfully this function should be called to store their
 * session. In production replace this with secure cookie or
 * session handling.
 */
export function saveUserToStorage(user: User) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
}

/**
 * Remove any stored user session. Calling this will effectively
 * log the visitor out and redirect them back to the login page.
 */
export function logout() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_KEY);
}

/**
 * Check whether a given user has at least the required tier. The
 * ordering of tiers is encoded here to simplify permission logic.
 */
export function hasRequiredTier(user: User | null, required: Tier): boolean {
  if (!user) return false;
  const order: Tier[] = ['Registered Collector', 'Auction Collector', 'Heritage Patron'];
  const userIndex = order.indexOf(user.tier);
  const requiredIndex = order.indexOf(required);
  return userIndex >= requiredIndex;
}