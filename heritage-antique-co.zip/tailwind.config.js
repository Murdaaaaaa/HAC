/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        parchment: 'var(--parchment)',
        'antique-gold': 'var(--antique-gold)',
        brass: 'var(--brass)',
        charcoal: 'var(--charcoal)',
        'ink-navy': 'var(--ink-navy)'
      },
      fontFamily: {
        display: ['var(--font-playfair)', 'serif'],
        serif: ['var(--font-cormorant)', 'serif'],
        script: ['var(--font-script)', 'cursive']
      }
    }
  },
  plugins: []
};